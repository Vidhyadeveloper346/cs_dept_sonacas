import React, { useState } from 'react';
import { BookOpen, Download, Plus, Trash2, Upload, Filter, Edit } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import Modal from './Modal';
import SyllabusForm from './SyllabusForm';

function Syllabus() {
  const { isAdmin } = useAuth();
  const { syllabus, deleteSyllabusItem } = useData();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedSemester, setSelectedSemester] = useState<number>(0);

  const semesters = [1, 2, 3, 4, 5, 6];
  
  const filteredSyllabus = selectedSemester === 0 
    ? syllabus 
    : syllabus.filter(item => item.semester === selectedSemester);

  const syllabusGrouped = filteredSyllabus.reduce((acc, item) => {
    if (!acc[item.semester]) {
      acc[item.semester] = [];
    }
    acc[item.semester].push(item);
    return acc;
  }, {} as Record<number, typeof syllabus>);

  const handleDownload = (fileName: string, subject: string) => {
    // Simulate file download
    alert(`Downloading ${subject} syllabus: ${fileName}`);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-gray-900">Course Syllabus</h1>
          <p className="text-gray-600 mt-2 text-lg">Semester-wise syllabus for all computer science subjects</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Semester Filter */}
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-500" />
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(parseInt(e.target.value))}
              className="border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value={0}>All Semesters</option>
              {semesters.map(sem => (
                <option key={sem} value={sem}>Semester {sem}</option>
              ))}
            </select>
          </div>

          {isAdmin() && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl transition-colors duration-200 shadow-lg hover:shadow-xl"
            >
              <Plus className="h-4 w-4" />
              <span>Upload Syllabus</span>
            </button>
          )}
        </div>
      </div>

      <div className="space-y-8">
        {Object.keys(syllabusGrouped).sort((a, b) => parseInt(a) - parseInt(b)).map((semesterKey) => {
          const semester = parseInt(semesterKey);
          const items = syllabusGrouped[semester];

          return (
            <div key={semester} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-3">
                  <div className="bg-blue-100 p-2 rounded-xl">
                    <BookOpen className="h-6 w-6 text-blue-600" />
                  </div>
                  <span>Semester {semester}</span>
                </h2>
                <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                  {items.length} subjects
                </span>
              </div>

              <div className="grid gap-4">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-6 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200 border border-gray-200">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.subject}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span className="flex items-center space-x-1">
                          <Upload className="h-4 w-4" />
                          <span>Uploaded: {new Date(item.uploadDate).toLocaleDateString()}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <FileText className="h-4 w-4" />
                          <span>{item.fileName}</span>
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => handleDownload(item.fileName, item.subject)}
                        className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl text-sm font-medium transition-colors duration-200 shadow-md hover:shadow-lg"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download PDF</span>
                      </button>
                      
                      {isAdmin() && (
                        <button
                          onClick={() => deleteSyllabusItem(item.id)}
                          className="p-3 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-xl transition-colors duration-200"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {Object.keys(syllabusGrouped).length === 0 && (
          <div className="text-center py-16">
            <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
              <BookOpen className="h-12 w-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No syllabus found</h3>
            <p className="text-gray-600 text-lg">
              {selectedSemester === 0 
                ? 'No syllabus documents have been uploaded yet.'
                : `No syllabus found for Semester ${selectedSemester}.`
              }
            </p>
          </div>
        )}
      </div>

      {/* Add Syllabus Modal */}
      {showAddModal && (
        <Modal title="Upload New Syllabus" onClose={() => setShowAddModal(false)}>
          <SyllabusForm onSuccess={() => setShowAddModal(false)} />
        </Modal>
      )}
    </div>
  );
}

export default Syllabus;