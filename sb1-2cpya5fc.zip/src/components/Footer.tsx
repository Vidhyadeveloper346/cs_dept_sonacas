import React from 'react';
import { GraduationCap } from 'lucide-react';

function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <GraduationCap className="h-6 w-6 text-blue-400" />
            <p className="text-xl font-bold text-white">Computer Science Department</p>
          </div>
          <p className="text-sm mb-4">Academic Excellence • Innovation • Research</p>
          <div className="border-t border-gray-700 pt-4">
            <p className="text-sm">© 2025 CS Department. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;