import React, { useState } from 'react';
import { FileText, Download, Plus, Trash2, BookOpen, Filter, Upload } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import Modal from './Modal';
import ReferenceForm from './ReferenceForm';

function References() {
  const { isAdmin } = useAuth();
  const { references, deleteReference } = useData();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedSemester, setSelectedSemester] = useState<number>(0);

  const semesters = [1, 2, 3, 4, 5, 6];
  
  const filteredReferences = selectedSemester === 0 
    ? references 
    : references.filter(ref => ref.semester === selectedSemester);

  const referencesGrouped = filteredReferences.reduce((acc, ref) => {
    const key = `${ref.semester}-${ref.subject}`;
    if (!acc[key]) {
      acc[key] = {
        semester: ref.semester,
        subject: ref.subject,
        notes: []
      };
    }
    acc[key].notes.push(ref);
    return acc;
  }, {} as Record<string, { semester: number; subject: string; notes: typeof references }>);

  const getFileIcon = (fileType: string) => {
    const icons = {
      pdf: '📄',
      docx: '📝',
      pptx: '📊'
    };
    return icons[fileType as keyof typeof icons] || '📄';
  };

  const getFileTypeColor = (fileType: string) => {
    const colors = {
      pdf: 'bg-red-100 text-red-800',
      docx: 'bg-blue-100 text-blue-800',
      pptx: 'bg-orange-100 text-orange-800'
    };
    return colors[fileType as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const handleDownload = (fileName: string, subject: string, unit: string) => {
    alert(`Downloading ${subject} - ${unit}: ${fileName}`);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-gray-900">Reference Notes</h1>
          <p className="text-gray-600 mt-2 text-lg">Subject-wise study materials and comprehensive notes</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Semester Filter */}
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-500" />
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(parseInt(e.target.value))}
              className="border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value={0}>All Semesters</option>
              {semesters.map(sem => (
                <option key={sem} value={sem}>Semester {sem}</option>
              ))}
            </select>
          </div>

          {isAdmin() && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl transition-colors duration-200 shadow-lg hover:shadow-xl"
            >
              <Plus className="h-4 w-4" />
              <span>Upload Notes</span>
            </button>
          )}
        </div>
      </div>

      <div className="space-y-8">
        {Object.values(referencesGrouped)
          .sort((a, b) => a.semester - b.semester)
          .map((group) => (
          <div key={`${group.semester}-${group.subject}`} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900 flex items-center space-x-3">
                <div className="bg-purple-100 p-2 rounded-xl">
                  <BookOpen className="h-6 w-6 text-purple-600" />
                </div>
                <span>Semester {group.semester} - {group.subject}</span>
              </h2>
              <span className="bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
                {group.notes.length} files
              </span>
            </div>

            <div className="grid gap-4">
              {group.notes.map((note) => (
                <div key={note.id} className="flex items-center justify-between p-6 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200 border border-gray-200">
                  <div className="flex items-center space-x-4">
                    <div className="text-3xl">{getFileIcon(note.fileType)}</div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">{note.unit}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span className="flex items-center space-x-1">
                          <Upload className="h-4 w-4" />
                          <span>Uploaded: {new Date(note.uploadDate).toLocaleDateString()}</span>
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getFileTypeColor(note.fileType)}`}>
                          {note.fileType.toUpperCase()}
                        </span>
                        <span className="text-gray-500">{note.fileName}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => handleDownload(note.fileName, note.subject, note.unit)}
                      className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl text-sm font-medium transition-colors duration-200 shadow-md hover:shadow-lg"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download</span>
                    </button>
                    
                    {isAdmin() && (
                      <button
                        onClick={() => deleteReference(note.id)}
                        className="p-3 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-xl transition-colors duration-200"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {Object.keys(referencesGrouped).length === 0 && (
          <div className="text-center py-16">
            <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
              <FileText className="h-12 w-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No reference notes found</h3>
            <p className="text-gray-600 text-lg">
              {selectedSemester === 0 
                ? 'No reference materials have been uploaded yet.'
                : `No reference notes found for Semester ${selectedSemester}.`
              }
            </p>
          </div>
        )}
      </div>

      {/* Add Reference Modal */}
      {showAddModal && (
        <Modal title="Upload Reference Notes" onClose={() => setShowAddModal(false)}>
          <ReferenceForm onSuccess={() => setShowAddModal(false)} />
        </Modal>
      )}
    </div>
  );
}

export default References;