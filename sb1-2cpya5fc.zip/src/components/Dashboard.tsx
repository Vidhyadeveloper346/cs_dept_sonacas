import React from 'react';
import { Calendar, BookOpen, FileText, Users, TrendingUp, Award, Clock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';

function Dashboard() {
  const { user, isAdmin } = useAuth();
  const { events, syllabus, references } = useData();

  const upcomingEvents = events.filter(event => new Date(event.date) >= new Date()).slice(0, 3);

  const stats = [
    { label: 'Total Events', value: events.length, icon: Calendar, color: 'bg-blue-500' },
    { label: 'Syllabus Items', value: syllabus.length, icon: BookOpen, color: 'bg-green-500' },
    { label: 'Reference Notes', value: references.length, icon: FileText, color: 'bg-purple-500' },
    { label: 'Semesters', value: 6, icon: TrendingUp, color: 'bg-orange-500' }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl text-white p-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              Welcome back, {user?.name}!
            </h1>
            <p className="text-blue-100 text-lg">
              {isAdmin() 
                ? 'Manage academic resources and events for the department'
                : 'Access your academic resources and stay updated with department events'
              }
            </p>
          </div>
          <div className="hidden md:block">
            {isAdmin() ? <Users className="h-16 w-16 text-blue-200" /> : <Award className="h-16 w-16 text-blue-200" />}
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Upcoming Events */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900 flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-blue-600" />
            <span>Upcoming Events</span>
          </h2>
          <span className="text-sm text-gray-500">{upcomingEvents.length} events</span>
        </div>

        {upcomingEvents.length > 0 ? (
          <div className="space-y-4">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{event.title}</h3>
                  <p className="text-gray-600 text-sm mt-1">{event.description}</p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span className="flex items-center space-x-1">
                      <Clock className="h-3 w-3" />
                      <span>{new Date(event.date).toLocaleDateString()} at {event.time}</span>
                    </span>
                    <span>📍 {event.venue}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-500 py-8">
            <Calendar className="h-12 w-12 mx-auto text-gray-300 mb-3" />
            <p>No upcoming events scheduled</p>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      {isAdmin() && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="flex items-center space-x-3 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors duration-200 text-left">
              <Calendar className="h-6 w-6 text-blue-600" />
              <div>
                <h3 className="font-medium text-gray-900">Add Event</h3>
                <p className="text-sm text-gray-600">Create new department event</p>
              </div>
            </button>
            <button className="flex items-center space-x-3 p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors duration-200 text-left">
              <BookOpen className="h-6 w-6 text-green-600" />
              <div>
                <h3 className="font-medium text-gray-900">Upload Syllabus</h3>
                <p className="text-sm text-gray-600">Add semester syllabus</p>
              </div>
            </button>
            <button className="flex items-center space-x-3 p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors duration-200 text-left">
              <FileText className="h-6 w-6 text-purple-600" />
              <div>
                <h3 className="font-medium text-gray-900">Add Notes</h3>
                <p className="text-sm text-gray-600">Upload reference materials</p>
              </div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;