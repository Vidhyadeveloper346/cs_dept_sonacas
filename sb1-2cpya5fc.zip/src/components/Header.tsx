import React from 'react';
import { GraduationCap, LogOut, User, Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="bg-blue-900 text-white shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-blue-800 p-3 rounded-xl">
              <GraduationCap className="h-10 w-10 text-blue-200" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Computer Science Department</h1>
              <p className="text-blue-200 text-lg">Academic Resources Portal</p>
            </div>
          </div>
          
          {user && (
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3 bg-blue-800 px-4 py-3 rounded-xl">
                {user.role === 'admin' ? (
                  <Shield className="h-5 w-5 text-orange-300" />
                ) : (
                  <User className="h-5 w-5 text-blue-300" />
                )}
                <div className="text-sm">
                  <div className="font-semibold">{user.name}</div>
                  <div className="text-blue-200 capitalize">{user.role}</div>
                </div>
              </div>
              <button
                onClick={logout}
                className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 px-4 py-3 rounded-xl transition-colors duration-200"
              >
                <LogOut className="h-4 w-4" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

export default Header;