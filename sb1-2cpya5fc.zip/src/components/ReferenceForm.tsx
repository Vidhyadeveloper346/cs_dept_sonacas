import React, { useState } from 'react';
import { BookOpen, FileText, Upload } from 'lucide-react';
import { useData } from '../contexts/DataContext';

interface ReferenceFormProps {
  onSuccess: () => void;
}

function ReferenceForm({ onSuccess }: ReferenceFormProps) {
  const { addReference } = useData();
  const [formData, setFormData] = useState({
    semester: 1,
    subject: '',
    unit: '',
    fileName: '',
    fileType: 'pdf' as 'pdf' | 'docx' | 'pptx'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Ensure filename has correct extension
    const extension = `.${formData.fileType}`;
    const fileName = formData.fileName.endsWith(extension) 
      ? formData.fileName 
      : `${formData.fileName}${extension}`;
    
    addReference({
      ...formData,
      fileName
    });
    onSuccess();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="semester" className="block text-sm font-medium text-gray-700 mb-2">
            <BookOpen className="inline h-4 w-4 mr-1" />
            Semester *
          </label>
          <select
            id="semester"
            name="semester"
            required
            value={formData.semester}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            {[1, 2, 3, 4, 5, 6].map(sem => (
              <option key={sem} value={sem}>Semester {sem}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="fileType" className="block text-sm font-medium text-gray-700 mb-2">
            File Type *
          </label>
          <select
            id="fileType"
            name="fileType"
            required
            value={formData.fileType}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="pdf">📄 PDF Document</option>
            <option value="docx">📝 Word Document</option>
            <option value="pptx">📊 PowerPoint Presentation</option>
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
          <FileText className="inline h-4 w-4 mr-1" />
          Subject Name *
        </label>
        <input
          type="text"
          id="subject"
          name="subject"
          required
          value={formData.subject}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          placeholder="e.g., Database Management Systems, Web Development"
        />
      </div>

      <div>
        <label htmlFor="unit" className="block text-sm font-medium text-gray-700 mb-2">
          Unit/Topic *
        </label>
        <input
          type="text"
          id="unit"
          name="unit"
          required
          value={formData.unit}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          placeholder="e.g., Unit 1 - Introduction, Chapter 5 - Advanced Topics"
        />
      </div>

      <div>
        <label htmlFor="fileName" className="block text-sm font-medium text-gray-700 mb-2">
          <Upload className="inline h-4 w-4 mr-1" />
          File Name *
        </label>
        <input
          type="text"
          id="fileName"
          name="fileName"
          required
          value={formData.fileName}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          placeholder={`reference_filename (${formData.fileType.toUpperCase()} extension will be added)`}
        />
        <p className="text-xs text-gray-500 mt-1">
          File extension (.{formData.fileType}) will be added automatically if not provided
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl">
        <div className="flex items-start space-x-3">
          <Upload className="h-5 w-5 text-blue-600 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-blue-800 mb-1">Secure File Upload</p>
            <p className="text-sm text-blue-700">
              In production, files would be securely uploaded to cloud storage with proper access controls. 
              Students can only download, while admins can upload and manage all documents.
            </p>
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-4 pt-4">
        <button
          type="button"
          onClick={onSuccess}
          className="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors duration-200"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors duration-200 shadow-lg hover:shadow-xl"
        >
          Upload Reference Notes
        </button>
      </div>
    </form>
  );
}

export default ReferenceForm;