import React from 'react';
import { BookOpen, FileText, Users, Award, Download, Upload, Shield, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';

function Home() {
  const { user, isAdmin } = useAuth();
  const { syllabus, references } = useData();

  const stats = [
    { 
      label: 'Total Semesters', 
      value: 6, 
      icon: BookOpen, 
      color: 'bg-blue-500',
      description: 'Complete curriculum coverage'
    },
    { 
      label: 'Syllabus Documents', 
      value: syllabus.length, 
      icon: FileText, 
      color: 'bg-green-500',
      description: 'Subject-wise syllabus available'
    },
    { 
      label: 'Reference Notes', 
      value: references.length, 
      icon: Download, 
      color: 'bg-purple-500',
      description: 'Study materials and notes'
    },
    { 
      label: 'Subjects Covered', 
      value: new Set(syllabus.map(s => s.subject)).size, 
      icon: Award, 
      color: 'bg-orange-500',
      description: 'Comprehensive subject coverage'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl text-white p-8 lg:p-12">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-4">
            Welcome to CS Department
          </h1>
          <p className="text-xl lg:text-2xl text-blue-100 mb-6">
            Your gateway to academic excellence and comprehensive learning resources
          </p>
          <div className="flex items-center justify-center space-x-8 text-blue-100">
            <div className="text-center">
              <div className="text-2xl font-bold">6</div>
              <div className="text-sm">Semesters</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{syllabus.length}</div>
              <div className="text-sm">Syllabus</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{references.length}</div>
              <div className="text-sm">References</div>
            </div>
          </div>
        </div>
      </div>

      {/* User Role Information */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Welcome, {user?.name}!
          </h2>
          <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full ${
            isAdmin() ? 'bg-orange-100 text-orange-800' : 'bg-blue-100 text-blue-800'
          }`}>
            {isAdmin() ? <Shield className="h-4 w-4" /> : <User className="h-4 w-4" />}
            <span className="font-medium capitalize">{user?.role} Access</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Capabilities */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-4">Your Capabilities</h3>
            <div className="space-y-3">
              {isAdmin() ? (
                <>
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <Upload className="h-5 w-5 text-green-600" />
                    <span className="text-gray-700">Upload & update syllabus documents</span>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <Upload className="h-5 w-5 text-green-600" />
                    <span className="text-gray-700">Upload & update reference notes</span>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <Users className="h-5 w-5 text-green-600" />
                    <span className="text-gray-700">Manage academic resources</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <BookOpen className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-700">View semester-wise syllabus</span>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <Download className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-700">Download syllabus documents</span>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <FileText className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-700">Access reference notes & materials</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Navigation</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                <div className="flex items-center space-x-3">
                  <BookOpen className="h-5 w-5 text-blue-600" />
                  <span className="font-medium text-gray-900">Syllabus</span>
                </div>
                <span className="text-sm text-gray-500">{syllabus.length} documents</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                <div className="flex items-center space-x-3">
                  <FileText className="h-5 w-5 text-purple-600" />
                  <span className="font-medium text-gray-900">Reference Notes</span>
                </div>
                <span className="text-sm text-gray-500">{references.length} files</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-200">
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} p-3 rounded-xl`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">{stat.label}</h3>
              <p className="text-sm text-gray-600">{stat.description}</p>
            </div>
          );
        })}
      </div>

      {/* Department Information */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">About CS Department</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Comprehensive Curriculum</h3>
            <p className="text-gray-600">Six-semester program covering all aspects of computer science from fundamentals to advanced topics.</p>
          </div>
          
          <div className="text-center">
            <div className="bg-green-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <FileText className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Rich Resources</h3>
            <p className="text-gray-600">Extensive collection of reference materials, notes, and study guides for every subject.</p>
          </div>
          
          <div className="text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Award className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Academic Excellence</h3>
            <p className="text-gray-600">Committed to providing quality education and fostering innovation in computer science.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;