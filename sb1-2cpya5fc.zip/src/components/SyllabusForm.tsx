import React, { useState } from 'react';
import { BookOpen, Upload, FileText } from 'lucide-react';
import { useData } from '../contexts/DataContext';

interface SyllabusFormProps {
  onSuccess: () => void;
}

function SyllabusForm({ onSuccess }: SyllabusFormProps) {
  const { addSyllabusItem } = useData();
  const [formData, setFormData] = useState({
    semester: 1,
    subject: '',
    fileName: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Ensure filename has .pdf extension
    const fileName = formData.fileName.endsWith('.pdf') 
      ? formData.fileName 
      : `${formData.fileName}.pdf`;
    
    addSyllabusItem({
      ...formData,
      fileName
    });
    onSuccess();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="semester" className="block text-sm font-medium text-gray-700 mb-2">
          <BookOpen className="inline h-4 w-4 mr-1" />
          Semester *
        </label>
        <select
          id="semester"
          name="semester"
          required
          value={formData.semester}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
        >
          {[1, 2, 3, 4, 5, 6].map(sem => (
            <option key={sem} value={sem}>Semester {sem}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
          <FileText className="inline h-4 w-4 mr-1" />
          Subject Name *
        </label>
        <input
          type="text"
          id="subject"
          name="subject"
          required
          value={formData.subject}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          placeholder="e.g., Programming in C, Data Structures"
        />
      </div>

      <div>
        <label htmlFor="fileName" className="block text-sm font-medium text-gray-700 mb-2">
          <Upload className="inline h-4 w-4 mr-1" />
          File Name *
        </label>
        <input
          type="text"
          id="fileName"
          name="fileName"
          required
          value={formData.fileName}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          placeholder="syllabus_filename (PDF extension will be added automatically)"
        />
        <p className="text-xs text-gray-500 mt-1">PDF extension will be added automatically if not provided</p>
      </div>

      <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl">
        <div className="flex items-start space-x-3">
          <Upload className="h-5 w-5 text-blue-600 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-blue-800 mb-1">File Upload Information</p>
            <p className="text-sm text-blue-700">
              In a production environment, this would include actual file upload functionality with secure cloud storage. 
              Currently, file metadata is stored for demonstration purposes.
            </p>
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-4 pt-4">
        <button
          type="button"
          onClick={onSuccess}
          className="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors duration-200"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors duration-200 shadow-lg hover:shadow-xl"
        >
          Upload Syllabus
        </button>
      </div>
    </form>
  );
}

export default SyllabusForm;