import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import Header from './components/Header';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import Login from './components/Login';
import Home from './components/Home';
import Syllabus from './components/Syllabus';
import References from './components/References';

function AppContent() {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'syllabus':
        return <Syllabus />;
      case 'references':
        return <References />;
      default:
        return <Home />;
    }
  };

  if (!user) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        {renderCurrentPage()}
      </main>
      
      <Footer />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </AuthProvider>
  );
}

export default App;