import React, { createContext, useContext, useState, ReactNode } from 'react';

interface SyllabusItem {
  id: string;
  semester: number;
  subject: string;
  fileName: string;
  uploadDate: string;
}

interface ReferenceNote {
  id: string;
  semester: number;
  subject: string;
  unit: string;
  fileName: string;
  fileType: 'pdf' | 'docx' | 'pptx';
  uploadDate: string;
}

interface DataContextType {
  syllabus: SyllabusItem[];
  addSyllabusItem: (item: Omit<SyllabusItem, 'id' | 'uploadDate'>) => void;
  deleteSyllabusItem: (id: string) => void;
  updateSyllabusItem: (id: string, item: Partial<SyllabusItem>) => void;
  references: ReferenceNote[];
  addReference: (reference: Omit<ReferenceNote, 'id' | 'uploadDate'>) => void;
  deleteReference: (id: string) => void;
  updateReference: (id: string, reference: Partial<ReferenceNote>) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [syllabus, setSyllabus] = useState<SyllabusItem[]>([
    { id: '1', semester: 1, subject: 'Programming in C', fileName: 'sem1_programming_c.pdf', uploadDate: '2025-01-01' },
    { id: '2', semester: 1, subject: 'Digital Electronics', fileName: 'sem1_digital_electronics.pdf', uploadDate: '2025-01-01' },
    { id: '3', semester: 1, subject: 'Mathematics I', fileName: 'sem1_mathematics.pdf', uploadDate: '2025-01-01' },
    { id: '4', semester: 2, subject: 'Data Structures', fileName: 'sem2_data_structures.pdf', uploadDate: '2025-01-01' },
    { id: '5', semester: 2, subject: 'Operating Systems', fileName: 'sem2_operating_systems.pdf', uploadDate: '2025-01-01' },
    { id: '6', semester: 2, subject: 'Mathematics II', fileName: 'sem2_mathematics.pdf', uploadDate: '2025-01-01' },
    { id: '7', semester: 3, subject: 'Database Management Systems', fileName: 'sem3_dbms.pdf', uploadDate: '2025-01-01' },
    { id: '8', semester: 3, subject: 'Computer Networks', fileName: 'sem3_networks.pdf', uploadDate: '2025-01-01' },
    { id: '9', semester: 3, subject: 'Software Engineering', fileName: 'sem3_software_engineering.pdf', uploadDate: '2025-01-01' },
    { id: '10', semester: 4, subject: 'Web Development', fileName: 'sem4_web_development.pdf', uploadDate: '2025-01-01' },
    { id: '11', semester: 4, subject: 'Machine Learning', fileName: 'sem4_machine_learning.pdf', uploadDate: '2025-01-01' },
    { id: '12', semester: 4, subject: 'Computer Graphics', fileName: 'sem4_computer_graphics.pdf', uploadDate: '2025-01-01' },
    { id: '13', semester: 5, subject: 'Artificial Intelligence', fileName: 'sem5_artificial_intelligence.pdf', uploadDate: '2025-01-01' },
    { id: '14', semester: 5, subject: 'Distributed Systems', fileName: 'sem5_distributed_systems.pdf', uploadDate: '2025-01-01' },
    { id: '15', semester: 5, subject: 'Cybersecurity', fileName: 'sem5_cybersecurity.pdf', uploadDate: '2025-01-01' },
    { id: '16', semester: 6, subject: 'Project Management', fileName: 'sem6_project_management.pdf', uploadDate: '2025-01-01' },
    { id: '17', semester: 6, subject: 'Advanced Algorithms', fileName: 'sem6_advanced_algorithms.pdf', uploadDate: '2025-01-01' },
    { id: '18', semester: 6, subject: 'Final Project', fileName: 'sem6_final_project.pdf', uploadDate: '2025-01-01' }
  ]);

  const [references, setReferences] = useState<ReferenceNote[]>([
    { id: '1', semester: 1, subject: 'Programming in C', unit: 'Unit 1 - Basics', fileName: 'c_basics.pdf', fileType: 'pdf', uploadDate: '2025-01-01' },
    { id: '2', semester: 1, subject: 'Programming in C', unit: 'Unit 2 - Control Structures', fileName: 'c_control_structures.pdf', fileType: 'pdf', uploadDate: '2025-01-01' },
    { id: '3', semester: 1, subject: 'Digital Electronics', unit: 'Unit 1 - Logic Gates', fileName: 'logic_gates.pptx', fileType: 'pptx', uploadDate: '2025-01-01' },
    { id: '4', semester: 2, subject: 'Data Structures', unit: 'Unit 1 - Arrays & Linked Lists', fileName: 'ds_arrays_linkedlists.pdf', fileType: 'pdf', uploadDate: '2025-01-01' },
    { id: '5', semester: 2, subject: 'Data Structures', unit: 'Unit 2 - Stacks & Queues', fileName: 'ds_stacks_queues.docx', fileType: 'docx', uploadDate: '2025-01-01' },
    { id: '6', semester: 3, subject: 'Database Management Systems', unit: 'Unit 1 - Introduction to DBMS', fileName: 'dbms_introduction.pdf', fileType: 'pdf', uploadDate: '2025-01-01' },
    { id: '7', semester: 3, subject: 'Database Management Systems', unit: 'Unit 2 - SQL Fundamentals', fileName: 'dbms_sql_fundamentals.pdf', fileType: 'pdf', uploadDate: '2025-01-01' },
    { id: '8', semester: 3, subject: 'Computer Networks', unit: 'Unit 1 - Network Basics', fileName: 'networks_basics.pptx', fileType: 'pptx', uploadDate: '2025-01-01' },
    { id: '9', semester: 4, subject: 'Web Development', unit: 'Unit 1 - HTML & CSS', fileName: 'web_html_css.pdf', fileType: 'pdf', uploadDate: '2025-01-01' },
    { id: '10', semester: 4, subject: 'Machine Learning', unit: 'Unit 1 - ML Fundamentals', fileName: 'ml_fundamentals.pdf', fileType: 'pdf', uploadDate: '2025-01-01' },
    { id: '11', semester: 5, subject: 'Artificial Intelligence', unit: 'Unit 1 - AI Overview', fileName: 'ai_overview.docx', fileType: 'docx', uploadDate: '2025-01-01' },
    { id: '12', semester: 6, subject: 'Advanced Algorithms', unit: 'Unit 1 - Algorithm Analysis', fileName: 'algorithms_analysis.pdf', fileType: 'pdf', uploadDate: '2025-01-01' }
  ]);

  const addSyllabusItem = (item: Omit<SyllabusItem, 'id' | 'uploadDate'>) => {
    const newItem: SyllabusItem = {
      ...item,
      id: Date.now().toString(),
      uploadDate: new Date().toISOString().split('T')[0]
    };
    setSyllabus(prev => [...prev, newItem]);
  };

  const deleteSyllabusItem = (id: string) => {
    setSyllabus(prev => prev.filter(item => item.id !== id));
  };

  const updateSyllabusItem = (id: string, updates: Partial<SyllabusItem>) => {
    setSyllabus(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const addReference = (reference: Omit<ReferenceNote, 'id' | 'uploadDate'>) => {
    const newReference: ReferenceNote = {
      ...reference,
      id: Date.now().toString(),
      uploadDate: new Date().toISOString().split('T')[0]
    };
    setReferences(prev => [...prev, newReference]);
  };

  const deleteReference = (id: string) => {
    setReferences(prev => prev.filter(ref => ref.id !== id));
  };

  const updateReference = (id: string, updates: Partial<ReferenceNote>) => {
    setReferences(prev => prev.map(ref => 
      ref.id === id ? { ...ref, ...updates } : ref
    ));
  };

  const value: DataContextType = {
    syllabus,
    addSyllabusItem,
    deleteSyllabusItem,
    updateSyllabusItem,
    references,
    addReference,
    deleteReference,
    updateReference
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}